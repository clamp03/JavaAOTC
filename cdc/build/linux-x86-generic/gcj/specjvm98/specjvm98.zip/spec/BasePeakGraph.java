/*
 * @(#)BasePeakGraph.java	1.8 06/29/98
 * A simple two-value bar graph to use in reporting pages
 * Ugly source code because (I confess) I lost the source for my
 * first version and recovered it from the class files.
 * Walter Bays
 *
 * Copyright (c) 1998 Standard Performance Evaluation Corporation (SPEC)
 *               All rights reserved.
 * Copyright (c) 1997,1998 Sun Microsystems, Inc. All rights reserved.
 *
 * This source code is provided as is, without any express or implied warranty.
 */

import java.awt.*;
import java.applet.Applet;

public class BasePeakGraph extends Applet
{
    private static final int MAX_ITEMS = 50;
    Graph graph;

    double getDoubleParameter(String string1)
    {
        String string2 = getParameter(string1);
        double d = 0.0;
        if (string2 != null) {
            try {
                d = Double.valueOf(string2).doubleValue();
            } catch (NumberFormatException e) { }
        }
        return d;
    }

    int getIntParameter(String string1, int i)
    {
	return getIntParameter (string1, i, 10);
    }

    int getIntParameter(String string1, int i, int radix)
    {
        String string2 = getParameter(string1);
        int j = i;
        if (string2 != null)
        {
            try
            {
                j = Integer.parseInt(string2, radix);
            }
            catch (NumberFormatException e)
            {
            }
        }
        return j;
    }

    public void init()
    {
        int i;
        for (i = 0; i <= 50 && getParameter(new StringBuffer("label").append(i).toString()) != null; i++) /* null body */ ;
        String astring[] = new String[i];
        double ad1[] = new double[i];
        double ad2[] = new double[i];
        for (int j = 0; j < i; j++)
        {
            astring[j] = getParameter(new StringBuffer("label").append(j).toString());
            ad1[j] = getDoubleParameter(new StringBuffer("base").append(j).toString());
            ad2[j] = getDoubleParameter(new StringBuffer("peak").append(j).toString());
        }
        graph = new Graph(astring, ad1, ad2, getIntParameter("decimals",-1),
	    getIntParameter("digits",3));
        graph.spacing = getIntParameter("space", 5);
        String string = getParameter("font");
        if (string != null)
            graph.fontName = string;
	graph.barColorRgb = getIntParameter ("color",0xff0000,16);
        graph.fontSize = getIntParameter("fontsize", 10);
        setBackground(Color.white);
	add (graph);
    }

    public void paint(Graphics g)
    {
        if (graph != null)
            graph.paint(g, size());
    }

    public boolean action(Event evt, Object arg){
	switch (evt.id){
	    case Event.SCROLL_ABSOLUTE:
	    case Event.SCROLL_LINE_UP:
	    case Event.SCROLL_PAGE_UP:
	    case Event.SCROLL_LINE_DOWN:
	    case Event.SCROLL_PAGE_DOWN:
	    case Event.WINDOW_EXPOSE:
	    case Event.WINDOW_DEICONIFY:
		boolean ok = super.action(evt,arg);
		repaint();
		return ok;
	}
	return super.action(evt,arg);
    }


    public BasePeakGraph()
    {
    }
}
