
/*
 * Floating-point.class removed from name file. 
 * Added check to not compare validity file during vreation.
 * These changes were made so it can work over Web server.
 * Kaivalya & Don Fri Jun 19 16:12:33 CDT 1998
 * Compares computed and stored checksums for all class, validity and some
 * source files. Reports installation failure on mismatch and asks user
 * to reinstall -- Kaivalya/Donald: Fri Jun 19 16:12:33 CDT 1998.
 *
 * Class_and_Validation_check.java Version 2.1 Fri Jun 19 16:12:33 CDT 1998
 *
 * Kaivalya wanted to make sure that class & validation files provided 
 * by SPEC would be used during the benchmark run. A User may accidently 
 * remove class files and recompile or accidently modiy validation files. 
 * This may or may not change the workload. 
 *
 * To detect such problems, this standalone program has created a file
 * using the MD5 digest for all validation & class files. A user can
 * run this utility to make sure that nothing iof importance was 
 * accidently modified.
 *
 * As usual, I needed significant help from Randy & Don and consultation 
 * with Walter.
 * Kaivalya M. Dixit/Randy Heisch/Don McCauley 5/28/98
 *
 * This should be run as a standalone program to detect any inadverent
 * modification of either class or validity files.
 *
 * Copyright (c) 1996 IBM Corporation, Inc. All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * IBM MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IBM SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * Kaivalya M. Dixit/Don McCauley/Randy Heisch IBM Corp. - Austin, TX
 *
 * SPEC development version @(#)Class_and_Validation_check.java 2.00 05/28/98
 */

package spec.benchmarks._999_checkit;
import spec.harness.*;
import java.security.*;
import spec.io.*;                // kmd/dm 6/19/98
import java.io.*;
import java.lang.*;
import java.util.*;


public class Class_and_Validation_check {
    
     public static long inst_main (String arg[]) {
    
     spec.io.FileInputStream in = null;        // validity file
     spec.io.FileInputStream in1 = null;       // class, validity, source files
     DataInputStream ifs = null;
     DataInputStream ifs1 = null;
    
     String line  ;
     String line1 ;
// prefix commented on 6/19/98
//     String prefix = "./spec/benchmarks/";     // relative path  dwm 6/17/98
     
     boolean reinstall = false;
	 
/*  commented on 6/19/98 -- Kaivalya         
    if (spec.harness.Context.getSpecBasePath() != "")
       prefix = spec.harness.Context.getSpecBasePath() + "spec/benchmarks/";


//    String filex     = prefix + "_999_checkit/names";           // dwm 6/17/87
//    String filename  = prefix + "_999_checkit/validity100.dat"; // dwm 6/17/98

*/
    
    String filex     = "names";           // dwm 6/19/98
    String filename  = "validity100.dat"; // dwm 6/19/98
    
    try {
//      in = new FileInputStream(filename);  // read validity file
        in = new spec.io.FileInputStream(filename);  // read validity file 6/19
        ifs = new DataInputStream (new BufferedInputStream (in) );
       }        

    catch (IOException ioe) {
         Context.out.println("ERROR opening/reading "+filename);
         Context.out.println("IOException: " + ioe.getMessage());  // dwm 6/17/98         
         return(1);                                                // dwm 6/17/98          
      };

    try {
        in1 = new spec.io.FileInputStream(filex);    // read names file
        ifs1 = new DataInputStream (new BufferedInputStream (in1) );
        }

    catch (IOException ioe) {
         System.out.println("ERROR opening/reading "+filex   );
         Context.out.println("IOException: " + ioe.getMessage());  // dwm 6/17/98         
         return(1);                                                // dwm 6/17/98  
      };

     try {
           while ((line1 = ifs1.readLine()) != null) { // read file  names
           MD5sum fcs    =  new MD5sum();              // compute checksum
           String line2  =  fcs.read (line1);          // line2 computed checksum
           if (! ProgramRunner.createValidityCheckFiles ) {   // dwm 6/19/98
	    line = ifs.readLine();                      // line from validity file
                                    
           if ( (line.compareTo(line2)) != 0 ) {
              System.out.println("\n\n<<<MD5checksum should be: " + line );
              System.out.println(">>>MD5checksum computed : " + line2 + "\n\n");
              reinstall = true;
                                               } // if compare
    }//  if create 
        }                                              // end while
           
     }                                                 // end try

     catch (IOException ioe) {
         System.out.println("ERROR opening/reading "+filex   );
         System.exit(1);
      };


   if ( reinstall ) {
          System.out.println ("\n\n           >>>>> WARNING WARNING WARNING <<<<<");
          System.out.println ("           >>>  YOUR FILES ARE CORRUPTED  <<<");
          System.out.println ("           >>>>>>>> PLEASE REINSTALL <<<<<<<<\n\n\n");
   }

   try {            // release resources
         ifs.close();
         ifs1.close();
         in.close();
         in1.close();
      }

   catch ( java.io.IOException IOE ) {};

   ifs    = null;
   ifs1   = null;
   in     = null;
   in1    = null;

   return 0;
 }
 

   }


