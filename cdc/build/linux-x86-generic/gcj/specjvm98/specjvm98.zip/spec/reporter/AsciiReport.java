/*
 * @(#)AsciiReport.java	1.5 08/07/98
 * Walter Bays
 *
 * Copyright (c) 1998 Standard Performance Evaluation Corporation (SPEC)
 *               All rights reserved.
 * Copyright (c) 1998 Sun Microsystems, Inc. All rights reserved.
 *
 * This source code is provided as is, without any express or implied warranty.
 *
 * I gave up on my hopes of the reporting software being reusable for
 * other SPEC benchmark suites. So as I add on this plain text report
 * capability, I abandon all that extra complexity that made the
 * original reporter template driven. What irony if the resulting
 * simpler code were thereby more likely to be reused. 
 */
 
package spec.reporter;

import java.io.*;
import java.util.Enumeration;
import java.util.Properties;

public class AsciiReport{

 ///////////////////////////////////////
//class variable field declarations
///////////////////////////////////////


///////////////////////////////////////
//instance variable field declarations
///////////////////////////////////////
public String		hardware, metric, software;
public String		base;
private String		category;
private TextColumn	columnTitle;
private TextColumn	columnValue;
public String		issue;
private String		memory;
public AsciiMetrics	metrics;
private final static int pageWidth = 79;
public ReportProps	results = new ReportProps();
public boolean		useJavaGraph;

///////////////////////////////////////
//constructor declarations
///////////////////////////////////////

public AsciiReport (String newsletter, String resultFile)
{
    this.issue = newsletter;
    try{
        if (resultFile == null)
            results.load (System.in, "standard input");
        else
            results.load (resultFile);
    }catch (IOException e){
	System.err.println (
	    "Error reading results file " + resultFile + ": " + e);
	System.exit(1);
    }
    metrics = new AsciiMetrics (results);
    this.hardware = get("spec.client.hw.vendor") + " " +
        get("spec.client.hw.model");
    if (metric == null)
	metric = metrics.composite();
    this.metric = metric;
    this.software = get("spec.client.sw.vendor") + " " +
        get("spec.client.sw.JVM");
    this.memory = results.get ("spec.client.hw.memory");
    this.category = categorizeMemory();
}

///////////////////////////////////////
//class method declarations
///////////////////////////////////////

///////////////////////////////////////
//instance method declarations
///////////////////////////////////////
private String categorizeMemory (){
    int cat1 = 48;
    int cat2 = 256;
    int mem = 0;
    try{
        cat1 = Integer.parseInt (results.get ("spec.report.cat1"));
        cat2 = Integer.parseInt (results.get ("spec.report.cat2"));
        mem =  Integer.parseInt (memory);
    }catch (Exception e){} // retain defaults
    if (mem <= 0)
	return "invalid category";
    else if (mem <= cat1)
	return "0 through " + cat1 + "MB category";
    else if (mem <= cat2)
	return cat1 + " through " + cat2 + " MB category";
    else
	return "over " + cat2 + " MB category";
}


private String configSection (){
    /*
     * Create title and value columns for the left side of the page
     * and join them, linked horizontally by logical elements
     * Then flatten it into a single block of text
     */
    TextBlock left = new TextBlock (37, "CLIENT HARDWARE");
    columnTitle = new TextColumn (16);
    columnValue = new TextColumn (20);
    cput ("spec.client.hw.vendor",	"Vendor");
    cput ("spec.client.hw.vendor.url",	"Vendor URL");
    cput ("spec.client.hw.model",	"Model");
    cput ("spec.client.hw.processor",	"Processor");
    cput ("spec.client.hw.MHz",		"MHz");
    cput ("spec.client.hw.ncpu",		"# of Procs");
    cput ("spec.client.hw.memory",	"Memory (MB)");
    cput ("spec.client.hw.primaryCache",	"L1 Cache");
    cput ("spec.client.hw.secondaryCache",	"L2 Cache");
    cput ("spec.client.hw.otherCache",	"Other Cache");
    cput ("spec.client.hw.memoryConfig",	"Mem. Config.");
    cput ("spec.client.hw.fileSystem",	"Filesystem");
    cput ("spec.client.hw.disk",		"Disks");
    cput ("spec.client.hw.nonVolatile",	"NV Storage");
    cput ("spec.client.hw.network",	"Network");
    cput ("spec.client.hw.other",	"Other H/W");
    left.add (columnTitle.join (columnValue, " ").merge());
    /*
     * Create title and value columns for the right side of the page
     * and join them, linked horizontally by logical elements
     * Then flatten it into a single block of text
     */
    TextBlock right = new TextBlock (37, "CLIENT SOFTWARE");
    columnTitle = new TextColumn (16);
    columnValue = new TextColumn (20);
    cput ("spec.client.sw.vendor",	"Vendor");
    cput ("spec.client.sw.vendor.url",	"Vendor URL");
    cput ("spec.client.sw.JVM",		"JVM Version");
    cput ("spec.client.sw.JVMmemory",	"Heap Mem (MB)");
    cput ("spec.client.sw.OS",		"OS Version");
    cput ("spec.client.sw.systemState",	"System state");
    cput ("spec.client.sw.other",	"Other S/W");
    right.add (columnTitle.join (columnValue, " ").merge());
    right.add ("");
    right.add ("TUNING NOTES");
    right.add (results.get ("spec.test.notes"));
    /*
     * Save these two columns, and then
     * start again top justifying a new set of text, so that
     * it looks like the HTML.
     */
    TextBlock top = left.join(right);
    top.add ("");
    /*
     * Create title and value columns for the left side of the page
     * and join them, linked horizontally by logical elements
     * Then flatten it into a single block of text
     */
    left = new TextBlock (37, "SERVER HARDWARE");
    columnTitle = new TextColumn (16);
    columnValue = new TextColumn (20);
    cput ("spec.server.hw.vendor",		"Vendor");
    cput ("spec.server.hw.model",		"Model");
    cput ("spec.server.hw.processor",		"Processor");
    cput ("spec.server.hw.MHz",			"MHz");
    cput ("spec.server.hw.ncpu",		"# of Procs");
    cput ("spec.server.hw.memory",		"Memory (MB)");
    cput ("spec.server.hw.fileSystem",		"Filesystem");
    cput ("spec.server.hw.disk",		"Disks");
    cput ("spec.server.hw.other",		"Other H/W");
    columnTitle.add ("");
    columnValue.add ("");
    columnTitle.add ("SERVER SOFTWARE");
    columnValue.add ("");
    cput ("spec.server.sw.OS",			"OS Version");
    cput ("spec.server.sw.webServer",		"Web server");
    cput ("spec.server.sw.other",		"Other S/W");
    left.add (columnTitle.join (columnValue, " ").merge());
    /*
     * Create title and value columns for the right side of the page
     * and join them, linked horizontally by logical elements
     * Then flatten it into a single block of text
     */
    right = new TextBlock (37, "TEST INFORMATION");
    columnTitle = new TextColumn (18);
    columnValue = new TextColumn (18);
    cput ("spec.test.testedBy",			"Tested by");
    cput ("spec.test.specLicense",		"SPEC License");
    cput ("spec.test.location",			"Test Location");
    cput ("spec.test.date",			"Test Date");
    cput ("spec.client.hw.available",		"Client h/w available");
    cput ("spec.client.sw.JVMavailable",	"JVM available");
    cput ("spec.client.sw.OSavailable",		"Client OS available");
    cput ("spec.client.sw.otherAvailable",	"Other client s/w available");
    cput ("spec.server.hw.available",		"Server h/w available");
    cput ("spec.server.sw.OSavailable",		"Server OS available");
    cput ("spec.server.sw.webAvailable",	"Web server available");
    cput ("spec.server.sw.otherAvailable",	"Other server s/w available");
    right.add (columnTitle.join (columnValue, " ").merge());
    /*
     * Finally, join the left and right blocks, add onto the top
     * section, and return the resulting string
     */
    top.add (left.join(right));
    return top.toString();
}

private void cput (String name, String title){
    columnTitle.add (title);
    columnValue.add (get (name));
}

private String get (String name){
    return get (name, "MISSING");
}

private String get (String name, String def){
    String s = results.get (name, def);
    if (s.indexOf ('<') >= 0){
        int i = s.indexOf ("<i>");
        if (i >= 0)
	    s = s.substring(0,i) + s.substring(i+3);
        i = s.indexOf ("<I>");
        if (i >= 0)
	    s = s.substring(0,i) + s.substring(i+3);
        i = s.indexOf ("</i>");
        if (i >= 0)
	    s = s.substring(0,i) + s.substring(i+4);
        i = s.indexOf ("</I>");
        if (i >= 0)
	    s = s.substring(0,i) + s.substring(i+4);
    }
    return s;
}

public void print (String outFile){
    try{
        print (new PrintStream(
            new BufferedOutputStream(
            new FileOutputStream (outFile)))
	    );
    }catch (IOException e){
	System.err.println ("Error creating output: " + e);
    }
}

public void print (PrintStream out){
    try{
        out.println ("SPEC JVM Client98");
	out.println (TextBlock.justifyRight (metric, pageWidth));
	out.println (TextBlock.justifyRight (
	    memory + " MB memory   " + category,
	    pageWidth));
	out.println();
	out.println (hardware);
	out.println (software);
	testBar (out);
	out.println ("\n                   SPEC Ratios");
	out.println (metrics.ratioTable());
	out.println();
	out.println (configSection());
	out.println (metrics.detail());
	out.println("\nSPECjvm98 version " +
	    results.get ("spec.report.version", "N/A") + ", " +
	    results.get ("spec.report.versionDate", "-"));
	if (issue != null && ! issue.equals("") && metrics.valid)
	    out.println("Published by SPEC " + issue);
	out.println(
	    "Reporting page (C) Copyright SPEC, 1998. " + 
	    "All rights reserved\n");
        out.close();
    }catch (Exception e){
        System.out.println("Error: " + e);
        e.printStackTrace();
    }
}

public void testBar (PrintStream out) throws IOException{
    String license = results.get ("spec.test.specLicense","MISSING");
    String testedBy = results.get ("spec.test.testedBy","MISSING");
    String testDate = results.get ("spec.test.date","MISSING");
    out.println(
            "SPEC license # " + license + ",  " +
            "Tested by: " + testedBy + ",  " +
            "Test date: " + testDate
    );
}

}//end class

