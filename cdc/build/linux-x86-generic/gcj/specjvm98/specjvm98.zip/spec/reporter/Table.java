/*
 * @(#)Table.java	1.6 06/17/98
 * Walter Bays
 *
 * Copyright (c) 1998 Standard Performance Evaluation Corporation (SPEC)
 *               All rights reserved.
 * Copyright (c) 1997,1998 Sun Microsystems, Inc. All rights reserved.
 *
 * This source code is provided as is, without any express or implied warranty.
 */

package spec.reporter;

import java.io.*;
import java.util.Properties;
import java.util.Vector;

public class Table{

///////////////////////////////////////
//class variable field declarations
///////////////////////////////////////

private static String tablePrefix =
    "<TABLE WIDTH=\"100%\" BORDER=1 CELLSPACING=2 CELLPADDING=0>" +
    "<TR><TH COLSPAN=2>\n";

///////////////////////////////////////
//instance variable field declarations
///////////////////////////////////////
private boolean		free;   // free format table. newline substitution. no title
private String		heading;
private Vector		items;
private ReportProps	props;
private ReportProps	titles;

///////////////////////////////////////
//constructor declarations
///////////////////////////////////////
Table(String h, DataInputStream in, ReportProps props, ReportProps titles, boolean free){
    heading = h;
    this.props = props;
    this.titles = titles;
    this.free = free;
    items = new Vector();
    String line;
    try{
        while ((line = in.readLine()) != null){
            if (line.equals("")) break;
            items.addElement(line);
        }
    }catch (IOException e){}
}

///////////////////////////////////////
//class method declarations
///////////////////////////////////////

///////////////////////////////////////
//instance method declarations
///////////////////////////////////////
private String expandN (String s){
    StringBuffer sb = new StringBuffer();
    char[] nb = new char [s.length()];
    s.getChars (0, nb.length, nb, 0);
    boolean sub = false;
    for (int i=0; i < nb.length - 1; i++)
	if (nb[i] == '\\' && nb[i+1] == 'n'){
	    sb.append ('\n');
	    i++;
	    sub = true;
	}else{
	    sb.append (nb[i]);
	    sub = false;
	}
    if (!sub)
	sb.append (nb[nb.length - 1]);
    return sb.toString();
}

public String toString(){
    StringBuffer buf = new StringBuffer(tablePrefix);
    buf.append(heading);
    buf.append("</TH></TR>\n");
    for (int i=0; i<items.size(); i++){
        String name = (String) items.elementAt(i);
	String label = titles.get(name);
	if (label == null)
	    label = name + "=null";
	String val = props.get(name);
	if (val == null || val.equals("")){
	    val = "&nbsp;";
	}else if (val.startsWith("http://")){
	    val = "<a href=\"" + val + "\">" + val + "</a>";
	}
	if (free){
	    buf.append("<TR><TD>");
	    buf.append(expandN (val));
	}else{
	    buf.append("<TR><TD><B>");
	    buf.append(label);
	    buf.append("</B></TD>\n<TD>");
	    buf.append(val);
	}
	buf.append("</TD></TR>\n");
    }
    buf.append("</TABLE>\n");
    return buf.toString();
}

}//end class

