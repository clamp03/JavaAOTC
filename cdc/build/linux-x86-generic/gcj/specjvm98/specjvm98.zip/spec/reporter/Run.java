/*
 * @(#)Run.java	1.8 07/08/98
 * Walter Bays
 *
 * Copyright (c) 1998 Standard Performance Evaluation Corporation (SPEC)
 *               All rights reserved.
 * Copyright (c) 1997,1998 Sun Microsystems, Inc. All rights reserved.
 *
 * This source code is provided as is, without any express or implied warranty.
 */

package spec.reporter;

import java.util.Properties;
import spec.reporter.Result;

public class Run{

///////////////////////////////////////
//class variable field declarations
///////////////////////////////////////
private final static double MB = 1024 * 1024;

///////////////////////////////////////
//instance variable field declarations
///////////////////////////////////////
public double			usedMemoryEnd;
public double			usedMemoryStart;
private ReportProps		props;
public Result			result;
public double			time;
public double			totalMemoryEnd;
public double			totalMemoryStart;

///////////////////////////////////////
//constructor declarations
///////////////////////////////////////
public Run (ReportProps props, int runNumber, double time, Result result){
    this.props = props;
    this.time = time;
    this.result = result;
    String prefix = "spec.results." + result.name + ".run" + runNumber;
    String s = props.get (prefix + ".valid");
    if (s == null || ! s.equals("true")){
	result.valid = false;
	result.invalidReason.append (result.name + " run " + runNumber +
	    " was not valid\n");
    }
    /*
     * This ought to never occur. In spec/io/ValidityCheckOutputStream.java
     * if there is any validity file difference the error count is
     * incremented which should cause the previous property (valid) to
     * be set to false. However, "only the paranoid survive," so double
     * check here to see that none of the underlying validity error
     * properties are set to be sure of a clean run
     */
    s = props.get (prefix + ".validity.error01");
    if (s != null){
	result.valid = false;
	result.invalidReason.append (result.name + " run " + runNumber +
	    " was not valid\n");
    }
    s = props.get (prefix + ".speed");
    if (s == null || ! s.equals("100")){
	result.valid = false;
	result.invalidReason.append (result.name + " run " + runNumber +
	    " used problem size " + s + " instead of 100\n");
    }
    s = props.get (prefix + ".stats.cache");
    if (s == null || s.equals("true")){
	result.valid = false;
	result.invalidReason.append (result.name + " run " + runNumber +
	    " had input cache enabled\n");
    }
    totalMemoryStart = getMB (prefix + ".stats.TotalMemoryStart");
    totalMemoryEnd = getMB (prefix + ".stats.TotalMemoryEnd");
    usedMemoryStart = totalMemoryStart - getMB (prefix + ".stats.FreeMemoryStart");
    usedMemoryEnd = totalMemoryEnd - getMB (prefix + ".stats.FreeMemoryEnd");
}

///////////////////////////////////////
//class method declarations
///////////////////////////////////////

///////////////////////////////////////
//instance method declarations
///////////////////////////////////////

private double getMB (String name){
    String s = props.get(name);
    if (s == null) return -1;
    try{
	Double number = new Double(s);
	return number.doubleValue() / MB;
    }catch (NumberFormatException e){
	return -1;
    }
}

public double ratio(){
    double ref = result.referenceTime;
    if (time <= 0)
	return 0;
    else
	return ref / time;
}

}//end class
