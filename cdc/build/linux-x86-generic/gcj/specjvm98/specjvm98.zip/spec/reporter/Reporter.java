/*
 * @(#)Reporter.java	1.14 08/07/98
 * Walter Bays
 *
 * Copyright (c) 1998 Standard Performance Evaluation Corporation (SPEC)
 *               All rights reserved.
 * Copyright (c) 1997,1998 Sun Microsystems, Inc. All rights reserved.
 *
 * This source code is provided as is, without any express or implied warranty.
 */
 
package spec.reporter;

import java.io.File;

public class Reporter{

///////////////////////////////////////
//class variable field declarations
///////////////////////////////////////

/*
 * Command line options
 */
private static boolean opta = false;
private static boolean opte = true;
private static String optj;
private static String optn;
private static String opto;
private static String optr;
private static String optS;
private static String optt = "props/title";
private static String optT = "props/report";
private static boolean optv = false;

///////////////////////////////////////
//instance variable field declarations
///////////////////////////////////////

///////////////////////////////////////
//constructor declarations
///////////////////////////////////////

///////////////////////////////////////
//class method declarations
///////////////////////////////////////

public static void main(String[] args){
    if (! getOpt(args))
	return;
    if (optS != null){
	optt = optS + java.io.File.separator + optt;
	optT = optS + java.io.File.separator + optT;
    }
    if (opta){
        AsciiReport r = new AsciiReport (optn, optr);
        if (opto == null)
	    r.print (System.out);
        else
	    r.print (opto);
    }else{
        Report r = new Report (opte, optj, optn, optr, optt, optT, optv);
        if (opto == null)
	    r.print (System.out);
        else
	    r.print (opto);
    }
}

private static boolean getOpt(String[] args){
    try{
	for (int i=0; i < args.length; i++)
	    if (args[i].equals("-a"))
		opta = true;
	    else if (args[i].equals("-e"))
		opte = false;
	    else if (args[i].equals("-j"))
		optj = args[++i];
	    else if (args[i].equals("-n"))
		optn = args[++i];
	    else if (args[i].equals("-o"))
		opto = args[++i];
	    else if (args[i].equals("-r"))
		optr = args[++i];
	    else if (args[i].equals ("-S"))
		optS = args[++i];
	    else if (args[i].equals("-t"))
		optt = args[++i];
	    else if (args[i].equals("-T"))
		optT = args[++i];
	    else if (args[i].equals("-v"))
		optv = true;
	    else
		throw new ArrayIndexOutOfBoundsException();
    }catch (ArrayIndexOutOfBoundsException e){
	usage();
	return false;
    }
    return true;
}

private static void usage(){
    System.out.println("Usage: java spec.reporter.Reporter [options]\n" +
      "Options are:\n" +
      "-a		 Plain ASCII text output\n" +
      "			   default: generate HTML output\n" +
      "-e                Do NOT echo raw results properties in HTML output\n" +
      "                    default: raw results inserted as HTML comments\n" +
      "-j Codebase       Display graph with Java applet\n" +
      "                    default: none (use GIF graph instead)\n" +
      "-o Output         Output file for generated HTML\n" +
      "                    default: written to System.out\n" +
      "-r Results        File containing a SPEC results file.\n" +
      "                    May be in a mail message with mail headers.\n" +
      "                    default: read from System.in\n" +
      "-S SpecDir        SPEC installation directory (to read templates)\n" +
      "                    default: current directory\n" +
      "-t Titles         File containing property titles\n" +
      "                    default: spec/title\n" +
      "-T Template       File containing report template\n" +
      "                    default: spec/report\n" +
      "-v                Verbose. List extra spec.testx.* properties\n" +
      "                    default: extra properties are not reported"
    );
}

///////////////////////////////////////
//instance method declarations
///////////////////////////////////////


}//end class

