/*
 * @(#)Report.java	1.19 08/07/98
 * Walter Bays
 *
 * Copyright (c) 1998 Standard Performance Evaluation Corporation (SPEC)
 *               All rights reserved.
 * Copyright (c) 1997,1998 Sun Microsystems, Inc. All rights reserved.
 *
 * This source code is provided as is, without any express or implied warranty.
 */
 
package spec.reporter;

import java.io.*;
import java.util.Enumeration;
import java.util.Properties;

public class Report{

 ///////////////////////////////////////
//class variable field declarations
///////////////////////////////////////

private static String logo =
    "<IMG SRC=\"images/spec-sm.gif\" WIDTH=\"57\" HEIGHT=\"72\"\n" +
    "ALT=\"[SPEC logo]\" ALIGN=MIDDLE>";
private final static String version = "@(#)Report.java	1.18 08/03/98";

///////////////////////////////////////
//instance variable field declarations
///////////////////////////////////////
public String		graphTable, hardware, metric, name, software;
public String		base;
private String		category;
public String		codeBase;
public boolean		echoRaw;
public String		issue;
private String		memory;
public Metrics		metrics;
public ReportProps	results = new ReportProps();
public String		templateFile;
public ReportProps	titles = new ReportProps();
public boolean		useJavaGraph;
public boolean		verbose;

///////////////////////////////////////
//constructor declarations
///////////////////////////////////////

public Report (boolean echoRaw, String codeBase, String newsletter,
    String resultFile, String titleFile, String templateFile, boolean verbose)
{
    this.echoRaw = echoRaw;
    this.codeBase = codeBase;
    this.issue = newsletter;
    this.templateFile = templateFile;
    this.verbose = verbose;
    useJavaGraph = codeBase != null;
    try{
        titles.load (titleFile);
    }catch (IOException e){
	System.err.println (
	    "Error reading title file " + titleFile + ": " + e + "\n" +
	    "Check your current directory, -S option, and -t option");
	System.exit(1);
    }
    try{
        if (resultFile == null)
            results.load (System.in, "standard input");
        else
            results.load (resultFile);
    }catch (IOException e){
	System.err.println (
	    "Error reading results file " + resultFile + ": " + e);
	System.exit(1);
    }
    metrics = new Metrics (results);
    this.graphTable = metrics.tableAndGraph (useJavaGraph, codeBase);
    this.name = results.get("spec.report.suiteName");
    this.hardware = results.get("spec.client.hw.vendor") + " " +
        results.get("spec.client.hw.model");
    if (metric == null)
	metric = metrics.composite();
    this.metric = metric;
    this.software = results.get("spec.client.sw.vendor") + " " +
        results.get("spec.client.sw.JVM");
    this.memory = results.get ("spec.client.hw.memory");
    this.category = categorizeMemory();
}

///////////////////////////////////////
//class method declarations
///////////////////////////////////////

///////////////////////////////////////
//instance method declarations
///////////////////////////////////////
private String categorizeMemory (){
    int cat1 = 48;
    int cat2 = 256;
    int mem = 0;
    try{
        cat1 = Integer.parseInt (results.get ("spec.report.cat1"));
        cat2 = Integer.parseInt (results.get ("spec.report.cat2"));
        mem =  Integer.parseInt (memory);
    }catch (Exception e){} // retain defaults
    if (mem <= 0)
	return "invalid category";
    else if (mem <= cat1)
	return "0 through " + cat1 + "MB category";
    else if (mem <= cat2)
	return cat1 + " through " + cat2 + " MB category";
    else
	return "over " + cat2 + " MB category";
}

public void print (String outFile){
    try{
        print (new PrintStream(
            new BufferedOutputStream(
            new FileOutputStream (outFile)))
	    );
    }catch (IOException e){
	System.err.println ("Error creating output: " + e);
    }
}

public void print (PrintStream out){
    try{
        out.println(
            "<HTML><HEAD>\n" +
	    "<META NAME=\"GENERATOR\" CONTENT=\"" +
                "SPEC Java Reporter\">\n" +
            "<TITLE> SPEC" + name + "</TITLE>\n" +
	    "</HEAD>");
	out.print(
	    "<BODY ");
	if (metrics.valid)
	    out.print (results.get("spec.report.bodyAttributes",""));
	else
	    out.print ("BACKGROUND=\"images/invalid.gif\"");
	out.print(
	    ">\n");
	out.print(
            "<TABLE WIDTH=100%>\n" +
	    "<TR><TD ROWSPAN=2>");
	if (issue != null && ! issue.equals(""))
	    out.print(logo);
	else
	    out.print ("<FONT SIZE=+3>SPEC</FONT>&nbsp;");
	out.print(
            "<FONT SIZE=+3>" + name + "</FONT></TD>\n" +
	    "<TD COLSPAN=2 ALIGN=RIGHT >" +
	    "    <FONT SIZE=+1 >" +
	    "    <B>" + metric + "</B></FONT></TD></TR>\n" +
	    "<TR><TD ALIGN=LEFT BGCOLOR=666666>&nbsp;\n" +
	    "        <FONT COLOR=FFFFFF><B>" + memory + "\n" +
	    "        MB memory</B></FONT></TD>\n" +
	    "    <TD ALIGN=RIGHT BGCOLOR=666666>\n" +
	    "        <FONT COLOR=FFFFFF><B>\n" + 
	    "    " + category + "&nbsp;</B></FONT></TD></TR>\n" +
            "<TR><TD COLSPAN=3><FONT SIZE=+1>" + hardware +
                "</FONT></TD></TR>\n");
        if (software != null) out.print(    
            "<TR><TD COLSPAN=3><FONT SIZE=+1>" + software +
                "</FONT></TD></TR>\n");
        out.println ("</TABLE>");
	out.println (graphTable);
	testBar (out);
	out.print(
	    "<P>\n");
        DataInputStream in = new DataInputStream(
            new BufferedInputStream( new FileInputStream(templateFile)));
        TableGroup m = new TableGroup(in,results,titles);
        out.println(m.toString());
	out.println(metrics.detail());
	if (useJavaGraph)
	    out.println (metrics.javaDetail(codeBase));
	if (verbose)
	    printOtherProperties (out);
	out.println("<HR><FONT SIZE=-1>\n");
	out.println("SPECjvm98 version " +
	    results.get ("spec.report.version", "N/A") + ", " +
	    results.get ("spec.report.versionDate", "-"));
	out.println ("<BR><I>\n");
	if (issue != null && ! issue.equals("") && metrics.valid)
	    out.println("Published by SPEC " + issue + "<br>");
	out.println(
	    "Reporting page (C) Copyright SPEC, 1998. " + 
	    "All rights reserved\n" +
	    "</I></FONT>");
        out.println ("<!-- ");
	out.println ("Reporting Page Generator " + version);
	if (echoRaw)
            results.save (out, "Raw Results");
        out.println (" -->");
        out.print(
            "</BODY></HTML>\n");
        out.close();
    }catch (Exception e){
        System.err.println("Error: " + e);
        e.printStackTrace();
    }
}

private void printOtherProperties (PrintStream out){
    out.println(
	"<H4>Optional Information</H4>\n" +
	"<I>This information is for internal documentation purposes\n" +
	"and is not required for SPEC reporting\n" +
	"</I><BR>");
    for (Enumeration e = results.propertyNames(); e.hasMoreElements(); ){
	String key = (String) e.nextElement();
	if (key.startsWith ("spec.testx.") || key.startsWith ("spec.initial.")){
	    String value = results.get (key);
	    if (key.equals ("spec.testx.internalReference") &&
		(value.startsWith ("http://") || value.startsWith ("file:/"))
	       )
		value = "<A HREF=\"" + value + "\">" + value + "</A>";
	    out.println ("<BR>" + key + "=" + value);
	}
    }
}

public void testBar (PrintStream out) throws IOException{
    String license = results.get ("spec.test.specLicense","MISSING");
    String testedBy = results.get ("spec.test.testedBy","MISSING");
    String testDate = results.get ("spec.test.date","MISSING");
    out.println(
        "<TABLE WIDTH=\"100%\" BORDER=1 CELLSPACING=2 CELLPADDING=0><tr>\n"+
            "<td width=33%><b>SPEC license # </b>" + license + "</td>\n"+
            "<td width=33%><b>Tested by: </b>" + testedBy + "</td>\n"+
            "<td><b>Test date: </b>" + testDate + "</td>\n"+
         "</tr></TABLE>"
    );
}

}//end class

