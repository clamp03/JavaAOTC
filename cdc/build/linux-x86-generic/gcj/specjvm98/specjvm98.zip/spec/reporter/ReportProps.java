/*
 * @(#)ReportProps.java	1.2 06/17/98
 * Walter Bays
 *
 * Copyright (c) 1998 Standard Performance Evaluation Corporation (SPEC)
 *               All rights reserved.
 * Copyright (c) 1997,1998 Sun Microsystems, Inc. All rights reserved.
 *
 * This source code is provided as is, without any express or implied warranty.
 */

package spec.reporter;
import java.io.*;
import java.util.Properties;

public class ReportProps extends Properties{

public String get (String key){
    return super.getProperty (key);
}

public String get (String key, String def){
    String s = super.getProperty (key);
    if (s == null)
	return def;
    return s;
}

public double getDouble (Object key){
    return getDouble (key, 0);
}

public double getDouble (Object key, double def){
    try{
	String s = (String) super.get (key);
	if (s != null)
	    return Double.valueOf(s).doubleValue();
    }catch (Exception e){}
    return def;
}

public int getInt (Object key){
    return getInt (key, 0);
}

public int getInt (Object key, int def){
    try{
	String s = (String) super.get (key);
	if (s != null)
	    return Integer.parseInt (s);
    }catch (Exception e){}
    return def;
}

public String getString (Object key){
    return (String) super.get (key);
}

public void load (String name) throws IOException{
    load (new FileInputStream (name), name);
}

public void load (InputStream in0, String name) throws IOException{
    DataInputStream in = new DataInputStream(
        new BufferedInputStream (in0));
    String line;
    while ((line = in.readLine()) != null){
        if (line.startsWith("#")) continue;
        int i = line.indexOf('=');
        if (i < 0) continue;
        String key = line.substring (0,i);
        String value = line.substring (i+1);
        put (key,value);
    }
}

}//end class
